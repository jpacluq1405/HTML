# Aprendiendo HTML

Mi repositorio de estudiante para aprender HTML paso a paso.

## Estructura

| Carpeta | Qué contiene |
|---|---|
| `ejercicios/` | Ejercicios cortos para probar una sola idea |
| `practicas/` | Prácticas que combinan varias etiquetas |
| `proyectos/` | Páginas web completas con CSS e imágenes |

## Índice

### Ejercicios
- [01 - Etiquetas básicas](ejercicios/01-etiquetas-basicas/index.html)
- [02 - Listas y enlaces](ejercicios/02-listas-y-enlaces/index.html)
- [03 - Imágenes y tablas](ejercicios/03-imagenes-y-tablas/index.html)

### Prácticas
- [01 - Formulario de contacto](practicas/01-formulario-de-contacto/index.html)

### Proyectos
- [Página personal](proyectos/pagina-personal/index.html)

## Cómo verlo
Descarga o clona el repositorio y abre cualquier `index.html` en tu navegador.

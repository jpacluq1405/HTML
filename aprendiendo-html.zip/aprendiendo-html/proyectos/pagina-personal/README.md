# Página personal

Mi primera web completa con HTML y CSS.

- `index.html`: estructura de la página
- `css/estilos.css`: estilos
- `img/`: imágenes
